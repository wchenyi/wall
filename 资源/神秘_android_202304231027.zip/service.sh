wait_until_login()
{
  # in case of /data encryption is disabled
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done

  # we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
  local test_file="/sdcard/Android/.CFMTEST"
  true > "$test_file"
  while [ ! -f "$test_file" ]; do
    true > "$test_file"
    sleep 1
  done
  rm "$test_file"
}

wait_until_login

sleep 5

dataDir="/data/adb/sfm"
logDir="${dataDir}/src/log"
termuxEnv="/data/data/com.termux/files/usr/bin"
busyBox="/data/adb/magisk/busybox"
workDir=$(cd $(dirname $0); pwd)

if [ -f ${termuxEnv}/node ] ; then
  sed -i '6cdescription=[node 环境加载正常]利用 Tun 支持 SingBox 的网络层代理.' ${workDir}/module.prop
  echo ${workDir} > ${dataDir}/src/modulePath
  nohup ${termuxEnv}/node ${dataDir}/bundle > /dev/null 2>&1 &
else
  sed -i '6cdescription=[未检测到 node 环境]利用 Tun 支持 SingBox 的网络层代理.' ${workDir}/module.prop
fi
